import java.util.Random;

/**
 * Trieda hracie pole predstavujuca sachovnicu
 * sklada sa z objektov Policko
 * B = Biela
 * Č = Čierna
 *
 * Sachovnica vyzera nasledovne:
 *   | A | B | C | D | E | F | G | H |
 * --+---+---+---+---+---+---+---+---+--
 * 8 | B | Č | B | Č | B | Č | B | Č | 8
 * --+---+---+---+---+---+---+---+---+--
 * 7 | Č | B | Č | B | Č | B | Č | B | 7
 * --+---+---+---+---+---+---+---+---+--
 * 6 | B | Č | B | Č | B | Č | B | Č | 6
 * --+---+---+---+---+---+---+---+---+--
 * 5 | Č | B | Č | B | Č | B | Č | B | 5
 * --+---+---+---+---+---+---+---+---+--
 * 4 | B | Č | B | Č | B | Č | B | Č | 4
 * --+---+---+---+---+---+---+---+---+--
 * 3 | Č | B | Č | B | Č | B | Č | B | 3
 * --+---+---+---+---+---+---+---+---+--
 * 2 | B | Č | B | Č | B | Č | B | Č | 2
 * --+---+---+---+---+---+---+---+---+--
 * 1 | Č | B | Č | B | Č | B | Č | B | 1
 * --+---+---+---+---+---+---+---+---+--
 *   | A | B | C | D | E | F | G | H |
 *
 *   pozicie policok su [RIADOK, STLPEC]
 *   napriklad: [8, A] je v poli sachovnica ako sachovnica[0][0]
 *   alebo [1, H] je v poli sachovnica ako sachovnica[7][7]
 *
 *   oznacenia riadkov a stlpcov su len pre userov, v pozadi to funguje klasicky,
 *   programatorsky: sachovnica[riadok][stlpec]
 */

public class HraciePole {


    private Policko[][] sachovnica;

    public HraciePole() {
        Random random = new Random();
        this.sachovnica = new Policko[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                this.sachovnica[i][j] = new Policko();
            }
        }
    }

    // int[] pozicia:
    // [0] = riadok
    // [1] = stlpec
    public void pridajPanacika(int[] pozicia, Panacik panacik) {
        Policko policko = this.sachovnica[pozicia[0]][pozicia[1]];
        if (!policko.jePanacikNaPolicku()) {
            policko.pridajPanacika(panacik);
        } else {
            System.out.println("Chyba! nemozno pridat na policko panacika, na policku uz sa nieco nachadza!");
        }
    }

    public void odoberPanacika(int[] pozicia) {
        Policko policko = this.sachovnica[pozicia[0]][pozicia[1]];
        policko.zoberPanacika();
    }

    public void presunPanacika(int[] odkial, int[] kam) {
        Policko polickoOdkial = this.sachovnica[odkial[0]][odkial[1]];
        Policko polickoKam = this.sachovnica[kam[0]][kam[1]];

        polickoKam.pridajPanacika(polickoOdkial.zoberPanacika());
    }

    /**
     * Metoda vracajuca policko na danej pozicii
     * @param pozicia [0] = riadok, [1] = stlpec
     * @return policko zo sachovnice na danej pozicii
     */
    public Policko getPolicko(int[] pozicia) {
        return this.sachovnica[pozicia[0]][pozicia[1]];
    }


    // zisti pocet panacikov danej farby na sachovnici...
    public int zistiPocetPanacikov(Farba farba) {
        int pocet = 0;

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (this.sachovnica[i][j].jePanacikNaPolicku()) {
                    if (this.sachovnica[i][j].getPanacik().getFarba() == farba) {
                        pocet++;
                    }
                }
            }
        }

        return pocet;
    }

    /**
     * toString sluziaci na vypis sachovnice rieseny formou podfarbenia (pozadia) znakov a farby znakov
     * v pripade cierneho policka je to cierne pozadie a medzery, ak sa tam nachadza panacik, do stredu sa
     * vypise jeho vyzor (pesiak alebo dama) kedze ale su problemy s tym, ze znaky maju rozlicne šírky
     * bola potreba to kompenzovat cez rozne siroke medzery...
     * @return formatovany string sachovnice pre vypis
     */
    @Override
    public String toString() {
        StringBuilder temp = new StringBuilder();
        for (int i = 0; i <= 8; i++) {
            // pismena
            if (i == 0) {
                temp.append("   ");
                for (int j = 0; j < 8; j++) {
                    temp.append((char)('A' + j)).append("  ");
                }
            } else {
                // cisla
                temp.append(9 - i).append(" ");
                //riadky
                // policka
                for (int j = 0; j < 8; j++) {
                    if (i % 2 == 0) {
                        if (j % 2 == 0) {
                            if (this.sachovnica[i - 1][j].jePanacikNaPolicku()) {
                                temp.append(KonzolaUtility.ANSI_BRIGHT_WHITE_BACKGROUND + KonzolaUtility.SPACE)
                                        .append(this.sachovnica[i - 1][j].toString())
                                        .append(KonzolaUtility.SPACE)
                                        .append(KonzolaUtility.ANSI_RESET);
                            } else {
                                temp.append(KonzolaUtility.ANSI_BRIGHT_WHITE_BACKGROUND + " ")
                                        .append(this.sachovnica[i - 1][j].toString())
                                        .append(" ")
                                        .append(KonzolaUtility.ANSI_RESET);
                            }

                        } else {
                            if (this.sachovnica[i - 1][j].jePanacikNaPolicku()) {
                                temp.append(KonzolaUtility.ANSI_BLACK_BACKGROUND + KonzolaUtility.SPACE)
                                        .append(this.sachovnica[i - 1][j].toString())
                                        .append(KonzolaUtility.SPACE)
                                        .append(KonzolaUtility.ANSI_RESET);
                            } else {
                                temp.append(KonzolaUtility.ANSI_BLACK_BACKGROUND + " ")
                                        .append(this.sachovnica[i - 1][j].toString())
                                        .append(" ")
                                        .append(KonzolaUtility.ANSI_RESET);
                            }

                        }
                    } else {
                        if (j % 2 == 0) {
                            if (this.sachovnica[i - 1][j].jePanacikNaPolicku()) {
                                temp.append(KonzolaUtility.ANSI_BLACK_BACKGROUND + KonzolaUtility.SPACE)
                                        .append(this.sachovnica[i - 1][j].toString())
                                        .append(KonzolaUtility.SPACE)
                                        .append(KonzolaUtility.ANSI_RESET);
                            } else {
                                temp.append(KonzolaUtility.ANSI_BLACK_BACKGROUND + " ")
                                        .append(this.sachovnica[i - 1][j].toString())
                                        .append(" ")
                                        .append(KonzolaUtility.ANSI_RESET);
                            }
                        } else {
                            if (this.sachovnica[i - 1][j].jePanacikNaPolicku()) {
                                temp.append(KonzolaUtility.ANSI_BRIGHT_WHITE_BACKGROUND + KonzolaUtility.SPACE)
                                        .append(this.sachovnica[i - 1][j].toString())
                                        .append(KonzolaUtility.SPACE)
                                        .append(KonzolaUtility.ANSI_RESET);
                            } else {
                                temp.append(KonzolaUtility.ANSI_BRIGHT_WHITE_BACKGROUND + " ")
                                        .append(this.sachovnica[i - 1][j].toString())
                                        .append(" ")
                                        .append(KonzolaUtility.ANSI_RESET);
                            }

                        }
                    }
                }
                temp.append(" ").append(9 - i);
            }
            temp.append("\n");
        }
        temp.append("   ");
        for (int j = 0; j < 8; j++) {
            temp.append((char)('A' + j)).append("  ");
        }
        return temp.toString();
    }
}
