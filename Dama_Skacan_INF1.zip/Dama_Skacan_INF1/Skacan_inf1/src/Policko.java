/**
 * Trieda Policko predstavujuca jedno policko hracieho pola
 * toto policko moze obsahovat panacika, alebo nemusi
 * v pripade ak ho neobsahuje je tam null
 */
public class Policko {
    private boolean jePanacikNaPolicku;
    private Panacik panacik;

    public Policko() {
        this.jePanacikNaPolicku = false;
        this.panacik = null;
    }

    public Policko(boolean jePanacikNaPolicku, Panacik panacik) {
        this.jePanacikNaPolicku = jePanacikNaPolicku;
        this.panacik = panacik;
    }

    /**
     * metoda ktora meni stav ci sa nachadza na policku panacik
     */
    public void zmenCiJePanacikNaPolicku() {
        this.jePanacikNaPolicku = !this.jePanacikNaPolicku;
    }

    /**
     * getter vracajuci stav policka
     * @return vrati true ak sa nachadza na policku panacik
     */
    public boolean jePanacikNaPolicku() {
        return this.jePanacikNaPolicku;
    }

    /**
     * setter, ktory "polozi" na policko panacika
     * @param panacik "polozi" panacika na policko
     */
    public void pridajPanacika(Panacik panacik) {
        this.panacik = panacik;
        this.zmenCiJePanacikNaPolicku();
    }

    /**
     * getter
     * @return panacik na policku
     */
    public Panacik getPanacik() {
        return this.panacik;
    }

    /**
     * metoda sluziaca na odobratie panacika a jeho nasledne vratenie
     * @return "zodvihne" panacika z policka pre presun vo vyssich triedach
     */
    public Panacik zoberPanacika() {
        Panacik temp = this.panacik;
        this.panacik = null;
        this.zmenCiJePanacikNaPolicku();
        return temp;
    }

    /**
     * toString panacika, panacik moze mat dva tvary, pesiak alebo dama, je to jeden char,
     * ktory je nastaveny pevne na zaklade typu panacika
     * @return vypisanie panacika vo forme stringu
     */
    @Override
    public String toString() {
        return this.jePanacikNaPolicku ? this.panacik.toString() : KonzolaUtility.EMPTY;
    }
}
