/**
 * Trieda Panacik predstavujuca jedneho panacika na policku
 * moze byt bud pesiak alebo dama, ich vyzor je odlisny (nachadza sa v triede KonzolaUtility)
 */
public class Panacik {
    private final Farba farba;
    private TypPanacika typPanacika;

    public Panacik(Farba farba, TypPanacika typPanacika) {
        this.farba = farba;
        this.typPanacika = typPanacika;
    }

    public Farba getFarba() {
        return this.farba;
    }

    public TypPanacika getTypPanacika() {
        return this.typPanacika;
    }

    /**
     * metoda na zmenu typu panacika v pripade ked sa dostane
     * na okraj sachovnice protivnika, vtedy sa zmeni na damu...
     * (tato funkcionalita je vyuzivana vo vyssej triede Dama)
     */
    public void zmenTypPanacika() {
        if (this.typPanacika == TypPanacika.PESIAK) {
            this.typPanacika = TypPanacika.DAMA;
        } else {
            this.typPanacika = TypPanacika.PESIAK;
        }
    }

    /**
     * toString panacika sluziaci pre vypis na sachovnicu
     * @return jeho vyzoru nachadzajuci sa v triede KonzolaUtility
     */
    @Override
    public String toString() {
        String temp = "";
        switch (this.typPanacika) {
            case PESIAK:
                temp = this.farba.toString() + KonzolaUtility.PESIAK;
                break;
            case DAMA:
                temp = this.farba.toString() + KonzolaUtility.DAMA;
                break;
            default:
                temp = KonzolaUtility.EMPTY;
                break;
        }
        return temp;
    }
}

