/**
 * Enum TypPanacika, predstavujuci typ panacika, v tomto pripade pesiaka a damy
 */
public enum TypPanacika {
    PESIAK, DAMA;
}
