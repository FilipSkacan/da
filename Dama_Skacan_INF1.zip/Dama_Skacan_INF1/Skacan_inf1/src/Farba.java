/**
 * Enum farieb panacikov, kedze sachovnica je ciernobiela, tak farby protivnikov
 * boli zvolene ako cervena a modra
 */
public enum Farba {
    CERVENA,
    MODRA;

    /**
     * toString sluziaci ako vypis farby, v tomto pripade sa vyuziva
     * pri vypise na konzolu, kedy zafarby vypis
     * napriklad System.out.println(Farba.CERVENA + "cervena" + KonzolaUtility.ANSI_RESET);
     * by vypisalo slovo "cervena" cervenou farbou...
     * @return farbu pre formatovany vypis
     */
    public String toString() {
        String temp = "";
        switch (this) {
            case MODRA:
                temp = KonzolaUtility.ANSI_BLUE;
                break;
            case CERVENA:
                temp = KonzolaUtility.ANSI_RED;
                break;
        }
        return temp;
    }
}

