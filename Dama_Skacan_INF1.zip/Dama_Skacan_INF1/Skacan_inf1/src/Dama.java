import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * Dáma (zjedondušená verzia)
 * Pravidlá:
 * - Hra sa hrá na 64 políčkach šachovnice (klasická šachovnica 8x8) po osem riadkov so striedaním
 * bielych a čiernych políčok v riadku.
 * - súperi majú na začiatku po osem figúrok pešiakov stojacich
 * na protiľahlých stranách v prvých dvoch radoch na čiernych políčkach
 * - všetky figúry sa pohybujú po diagonálach, nemôžu preskakovať figúrky vlastnej farby
 * - Pešiaci sa pohybujú iba dopredu. Ak neberú súperovu figúru, pohybujú sa po jednom políčku.
 * Ak berú súperovu figúru, preskočia ju a tak ju zoberú,
 * ak môžu preskočiť aj ďalšiu súperovi figúrku, môžu preskočiť a zobrať aj tú
 * - Keď pešiak dôjde na druhú stranu šachovnice, zmení sa na dámu
 * - Dáma sa pohybuje dopredu aj dozadu o ľubovoľný počet polí
 *
 * Vyhráva hráč, ktorý zoberie súperovi všetky figúrky.
 *
 *
 * ~~~ NASLEDOVNE PRAVIDLA som neimplementoval, lebo boli komplikovane ~~~
 * - Ak v danom ťahu hráč môže vyhodiť súperovu figúrku, ale žiadnu nevyhodí, súper mu za trest môže figúrku,
 * ktorá mohla brať pred uskutočnením vlastného ťahu, vziať.
 * Ak figúrka, ktorou ťahal, mohla vziať ešte ďalšiu figúrku, súper mu ju môže pred vlastným ťahom vziať
 * - Dáma má prednosť. Ak hráč môže vziať súperovi figúrku (figúrky) pešiakom aj dámou a vezme pešiakom,
 * protihráč mu pred uskutočnením vlastného ťahu môže dámu, ktorá mohla brať, zobrať
 * Partia končí remízou:
 * a) ak hráč, ktorý je na ťahu, nemôže uskutočniť ťah;
 * b) ak už teoreticky nemožno pri pozornej hre súperovi vziať žiadnu figúrku
 */

public class Dama {
    public Dama() {

        // zaciatocny user input - tu si uzvatel vybera hracov, a kto bude zacinat (zacina sa cervenou)
        boolean koniec = false;
        Scanner scanner = new Scanner(System.in);
        Hrac[] hraci = new Hrac[2];

        String[] menaHracov = new String[2];

        System.out.println("Zadajte meno prveho hraca: ");
        menaHracov[0] = scanner.next();
        System.out.println("Zadajte meno druheho hraca: ");
        menaHracov[1] = scanner.next();

        do {
            System.out.println("Vyberte kto bude zacinat, " + menaHracov[0] + " alebo " + menaHracov[1]);
            System.out.println("Zacina " + Farba.CERVENA + "cervena" + KonzolaUtility.ANSI_RESET + " farba");
            System.out.println("1 - " + menaHracov[0] + " bude zacinat");
            System.out.println("2 - " + menaHracov[1] + " bude zacinat");
            System.out.println("0 - nahodny vyber");

            String volba = scanner.next();

            int zacinajuciHrac = -1;

            switch (volba) {
                case "0":
                    // nahodny vyber 50/50
                    Random random = new Random();
                    if (random.nextInt() % 2 == 0) {
                        zacinajuciHrac = 0;
                    } else {
                        zacinajuciHrac = 1;
                    }
                    break;
                case "1":
                    zacinajuciHrac = 0;
                    break;

                case "2":
                    zacinajuciHrac = 1;
                    break;
                default:
                    System.out.println("Nespravna volba...");
            }

            if (zacinajuciHrac != -1) {
                System.out.println("Zacina hrac (" + Farba.CERVENA + "cervena" + KonzolaUtility.ANSI_RESET + "): " + menaHracov[zacinajuciHrac]);
                hraci[0] = new Hrac(Farba.CERVENA, menaHracov[0]);
                hraci[1] = new Hrac(Farba.MODRA, menaHracov[1]);
                koniec = true;
            }
        } while (!koniec);

        HraciePole hraciePole = new HraciePole();

        // vytvorenie panacikov hracov na hracie pole
        for (int i = 0; i < 4; i++) {
            int[] pozicia = new int[2];

//            pozicia[0] = 0;
            pozicia[1] = 1 + 2 * i;

            hraciePole.pridajPanacika(pozicia, new Panacik(Farba.MODRA, TypPanacika.PESIAK));

            pozicia[0] = 1;
            pozicia[1] = 2 * i;

            hraciePole.pridajPanacika(pozicia, new Panacik(Farba.MODRA, TypPanacika.PESIAK));

            pozicia[0] = 6;
            pozicia[1] = 1 + 2 * i;

            hraciePole.pridajPanacika(pozicia, new Panacik(Farba.CERVENA, TypPanacika.PESIAK));

            pozicia[0] = 7;
            pozicia[1] = 2 * i;

            hraciePole.pridajPanacika(pozicia, new Panacik(Farba.CERVENA, TypPanacika.PESIAK));
        }


        // cela logika hry (user inputy, tahy)
        koniec = false;
        int kolo = 0;

        while (!koniec) {
            System.out.println("=========================================================================");
            System.out.println("Kolo: " + (kolo + 1));
            System.out.println("Hrac na rade: " + hraci[kolo % 2].getFarba() + "██ " + KonzolaUtility.ANSI_RESET + hraci[kolo % 2].getMeno());


            // vyber figurky
            boolean koniecVyberFigurky = false;
            int[] poziciaOdkial = new int[2]; // pozicia figurky

            do {
                System.out.println(hraciePole.toString());
                String userInput = "";
                System.out.println("Zadajte poziciu figurky, ktoru chcete pohnut, vo formate riadokSTLPEC, napriklad: 3C, 1a, 8H");

                userInput = scanner.next();

                // osetrenie user inputu, tak aby to bolo vzdy 2 suradnice a vo formate RIADOK|STLPEC napr. 3C, 1A, ...
                if (userInput.length() != 2
                        || !Character.isDigit(userInput.charAt(0))
                        || !Character.isAlphabetic(userInput.toLowerCase().charAt(1))
                ) {
                    System.out.println("Nezadali ste poziciu figurky v spravnom tvare");
                    continue;
                }

                // kvoli pretypovavaniu sa musi odpocitavat nulty prvok, lebo cisla nezacinaju v ascii tabulke od 0
                // a kvoli tomu ze clovek zadava cisla od 1 do 8 sa musi odcitavat 1, aby to bolo lepsie pre stroj
                // lebo policka su cislovane od 0 po 7
                int poziciaRiadok = userInput.charAt(0) - '0' - 1;
                int poziciaStlpec = userInput.toLowerCase().charAt(1) - 'a'; // to iste plati tu, len pre pismena...

                // kontrola ci sa nachadza v range 0 - 7 (pre usera 1 - 8 a A - H)
                if (poziciaRiadok > 7
                        || poziciaRiadok < 0
                        || poziciaStlpec > 7
                        || poziciaStlpec < 0
                ) {
                    System.out.println("Taketo policko sa nenachadza na sachovnici...");
                    continue;
                }

                // prerobenie user inputu na programom vyuzitelne suradnice
                poziciaRiadok = 7 - poziciaRiadok;

                // kontrola, ci bol vobec vybraty panacik, a nie len random policko
                poziciaOdkial[0] = poziciaRiadok;
                poziciaOdkial[1] = poziciaStlpec;
                if (!hraciePole.getPolicko(poziciaOdkial).jePanacikNaPolicku()) {
                    System.out.println("Na danom policku sa nenachadza figurka...");
                    continue;
                }

                // kontrola ci je panacik vobec farby hraca ktory je na tahu
                if (hraciePole.getPolicko(poziciaOdkial).getPanacik().getFarba() != hraci[kolo % 2].getFarba()) {
                    System.out.println("Tato figurka vam nepatri, prosim vyberte len svoju figurku...");
                    continue;
                }

                koniecVyberFigurky = true;
            } while (!koniecVyberFigurky);

            // vykonanie tahu (metoda vykonajTah nam vracia, ci bol vobec vykonany tah)
            if (!this.vykonajTah(hraciePole, hraci[kolo % 2].getFarba(), poziciaOdkial)) {
                continue;
            }

            // kontrola, ci uz dosli figurky niekomu, komu dosli, ten pehral.
            // hraci[0] je vzdy cerveny!
            int pocetCervenych = hraciePole.zistiPocetPanacikov(hraci[0].getFarba());
            int pocetModrych = hraciePole.zistiPocetPanacikov(hraci[1].getFarba());

            // vyhodnotenie hry na zaklade poctov
            if (pocetCervenych == 0) {
                System.out.println(hraciePole.toString());
                System.out.println("Vyhrava " + Farba.MODRA + "██ " + KonzolaUtility.ANSI_RESET + hraci[1].getMeno());
                break;
            }
            if ( pocetModrych == 0) {
                System.out.println(hraciePole.toString());
                System.out.println("Vyhrava " + Farba.CERVENA + "██ " + KonzolaUtility.ANSI_RESET + hraci[0].getMeno());
                break;
            }

            kolo++;
        }
    }


    /**
     * Metoda vykonajTah ktora sluzi na vykonanie tahu, na zaklade user-inputu ktory si vyziada.
     *
     * @return vracia ci sa tah vykonal, v pripade ze sa nevykonal (napriklad, nedalo sa s danym panacikom
     * pohnut - nemal tahy) vrati false
     */
    private boolean vykonajTah(HraciePole hraciePole, Farba farbaHraca, int[] poziciaFigurky) {
        boolean konciKolo = false;
        Scanner scanner = new Scanner(System.in);
        boolean preskakovaloSa = false;
        boolean bolVykonanyTah = true;

        // CERVENA = zdola nahor
        // MODRA = zhora nadol
        // kody su rovnake, len cisla su otocene
        while (!konciKolo) {

            int[] poziciaVedla1 = new int[2];
            int[] poziciaVedla2 = new int[2];
            int[] poziciaVedla11 = new int[2]; // pozicia za protivnikovou figurkou
            int[] poziciaVedla21 = new int[2]; // pozicia za protivnikovou figurkou
            ArrayList<int[]> tahy = new ArrayList<>();
            ArrayList<Integer> posuny = new ArrayList<>();

            if (hraciePole.getPolicko(poziciaFigurky).getPanacik().getTypPanacika() != TypPanacika.DAMA) {
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ LOGIKA PESIAKA ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                if (farbaHraca == Farba.CERVENA) {
                    // najprv zistenie, ci sa vobec da nejaky tah vykonat...
                    // to znamena, ze je nie niekde v okoli take policko, na ktorom sa nenachadza nikto
                    // alebo ak sa nachadza protivnikova figurka, tak za nou ci sa nachadza prazdne policko
                    // pozicia vedla1 predtsavuje poziciu nalavo od aktualnej figurky, pozicia vedla2 napravo...

                    poziciaVedla1[0] = poziciaFigurky[0] - 1;
                    poziciaVedla1[1] = poziciaFigurky[1] - 1;


                    poziciaVedla2[0] = poziciaFigurky[0] - 1;
                    poziciaVedla2[1] = poziciaFigurky[1] + 1;

                    int mozneTahy = 0; // mozne tahy: aspoň 0

                    // zistenie mozneho tahu smerom dolava
                    if (poziciaVedla1[0] >= 0 && poziciaVedla1[0] <= 7 && poziciaVedla1[1] >= 0 && poziciaVedla1[1] <= 7) {
                        if (hraciePole.getPolicko(poziciaVedla1).jePanacikNaPolicku()) {
                            if (hraciePole.getPolicko(poziciaVedla1).getPanacik().getFarba() != farbaHraca) {
                                if (poziciaVedla1[0] - 1 >= 0 && poziciaVedla1[0] - 1 <= 7 && poziciaVedla1[1] - 1 >= 0 && poziciaVedla1[1] - 1 <= 7) {
                                    poziciaVedla11[0] = poziciaVedla1[0] - 1;
                                    poziciaVedla11[1] = poziciaVedla1[1] - 1;

                                    if (!hraciePole.getPolicko(poziciaVedla11).jePanacikNaPolicku()) {
                                        tahy.add(poziciaVedla11);
                                        posuny.add(2);
                                    }
                                }
                            }
                        } else {
                            tahy.add(poziciaVedla1);
                            posuny.add(1);
                        }
                    }

                    // zistenie mozneho tahu smerom doprava
                    if (poziciaVedla2[0] >= 0 && poziciaVedla2[0] <= 7 && poziciaVedla2[1] >= 0 && poziciaVedla2[1] <= 7) {
                        if (hraciePole.getPolicko(poziciaVedla2).jePanacikNaPolicku()) {
                            if (hraciePole.getPolicko(poziciaVedla2).getPanacik().getFarba() != farbaHraca) {
                                if (poziciaVedla2[0] - 1 >= 0 && poziciaVedla2[0] - 1 <= 7 && poziciaVedla2[1] + 1 >= 0 && poziciaVedla2[1] + 1 <= 7) {
                                    poziciaVedla21[0] = poziciaVedla2[0] - 1;
                                    poziciaVedla21[1] = poziciaVedla2[1] + 1;

                                    if (!hraciePole.getPolicko(poziciaVedla21).jePanacikNaPolicku()) {
                                        tahy.add(poziciaVedla21);
                                        posuny.add(2);
                                    }
                                }
                            }
                        } else {
                            tahy.add(poziciaVedla2);
                            posuny.add(1);
                        }
                    }

                    // ak su vobec nejake tahy, tak nech si uzivatel vyberie ktory tah chce vykonat...
                    if (tahy.size() > 0) {
                        boolean koniecVyberuTahu = false;
                        int volba = -1;
                        int[] staraPoziciaFigurky = new int[2];

                        do {
                            System.out.println(hraciePole.toString());
                            String userInput = "";
                            System.out.println("Vyberte cislo tahu, ktory chcete vykonat: ");

                            for (int i = 0; i < tahy.size(); i++) {
                                System.out.println((i + 1) + ". - Tah " + "[" + (8 - poziciaFigurky[0]) + ", " + (char)(poziciaFigurky[1] + 'A') + "] -"
                                        + posuny.get(i) + "->"
                                        + " [" + (8 - tahy.get(i)[0]) + ", " + (char)(tahy.get(i)[1] + 'A') + "]");
                            }

                            userInput = scanner.next();

                            if (!Character.isDigit(userInput.charAt(0))) {
                                System.out.println("Prosim zadajte cislo...");
                                continue;
                            }

                            int temp = (userInput.charAt(0) - '0') - 1;

                            if (temp < 0 || temp >= tahy.size()) {
                                System.out.println("Prosim vyberte volbu zo zoznamu...");
                                continue;
                            }

                            volba = temp;
                            koniecVyberuTahu = true;
                        } while (!koniecVyberuTahu);

                        // vyradenie protivnikovej figurky
                        if (posuny.get(volba) == 2) {
                            preskakovaloSa = true;

                            int[] odoberanyPanacik = new int[2];

                            // ktorym smerom sme isli, ak sme sli doprava, vieme to zistit tak, ze spocitame dohromady suradnice,
                            // ak su rovnake ako povodna pozicia, tak sme sli doprava, inak dolava...
                            if ((poziciaFigurky[0] + poziciaFigurky[1]) == (tahy.get(volba)[0] + tahy.get(volba)[1])) {
                                odoberanyPanacik[0] = poziciaFigurky[0] - 1;
                                odoberanyPanacik[1] = poziciaFigurky[1] + 1;
                            } else {
                                odoberanyPanacik[0] = poziciaFigurky[0] - 1;
                                odoberanyPanacik[1] = poziciaFigurky[1] - 1;
                            }

                            hraciePole.odoberPanacika(odoberanyPanacik);

                            int[] poziciaZaVyradenym1 = new int[2];
                            poziciaZaVyradenym1[0] = tahy.get(volba)[0] - 1;
                            poziciaZaVyradenym1[1] = tahy.get(volba)[1] - 1;
                            int[] poziciaZaVyradenym2 = new int[2];
                            poziciaZaVyradenym2[0] = tahy.get(volba)[0] - 1;
                            poziciaZaVyradenym2[1] = tahy.get(volba)[1] + 1;

                            // zistovanie, ci sa este da znovu skakat - lava strana
                            if (poziciaZaVyradenym1[0] >= 0 && poziciaZaVyradenym1[0] <= 7 && poziciaZaVyradenym1[1] >= 0 && poziciaZaVyradenym1[1] <= 7) {
                                if (hraciePole.getPolicko(poziciaZaVyradenym1).jePanacikNaPolicku()) {
                                    if (hraciePole.getPolicko(poziciaZaVyradenym1).getPanacik().getFarba() != farbaHraca) {
                                        if (poziciaZaVyradenym1[0] - 1 >= 0 && poziciaZaVyradenym1[0] - 1 <= 7 && poziciaZaVyradenym1[1] - 1 >= 0 && poziciaZaVyradenym1[1] - 1 <= 7) {
                                            if (!hraciePole.getPolicko(poziciaVedla11).jePanacikNaPolicku()) {
                                                // da sa preskocit
                                                konciKolo = false;
                                            } else {
                                                // niekto tam stoji za nim, neda sa preskocit
                                                konciKolo = true;
                                            }
                                        } else {
                                            // mimo sachovnice by som skakal, lebo je na kraji
                                            konciKolo = true;
                                        }
                                    } else {
                                        // moj panacik nejde preskocit
                                        konciKolo = true;
                                    }
                                } else {
                                    // prazdne policko, nemozem nikoho preskocit
                                    konciKolo = true;
                                }
                            } else {
                                // mimo sachovnice by som siel
                                konciKolo = true;
                            }

                            // zistovanie, ci sa este da znovu skakat - prava strana
                            if (poziciaZaVyradenym2[0] >= 0 && poziciaZaVyradenym2[0] <= 7 && poziciaZaVyradenym2[1] >= 0 && poziciaZaVyradenym2[1] <= 7) {
                                if (hraciePole.getPolicko(poziciaZaVyradenym2).jePanacikNaPolicku()) {
                                    if (hraciePole.getPolicko(poziciaZaVyradenym2).getPanacik().getFarba() != farbaHraca) {
                                        if (poziciaZaVyradenym2[0] - 1 >= 0 && poziciaZaVyradenym2[0] - 1 <= 7 && poziciaZaVyradenym2[1] + 1 >= 0 && poziciaZaVyradenym2[1] + 1 <= 7) {
                                            if (!hraciePole.getPolicko(poziciaVedla21).jePanacikNaPolicku()) {
                                                // da sa preskocit
                                                konciKolo = false;
                                            } else {
                                                // niekto tam stoji za nim, neda sa preskocit
                                                konciKolo = true;
                                            }
                                        } else {
                                            // mimo sachovnice by som skakal, lebo je na kraji
                                            konciKolo = true;
                                        }
                                    } else {
                                        // moj panacik nejde preskocit
                                        konciKolo = true;
                                    }
                                } else {
                                    // prazdne policko, nemozem nikoho preskocit
                                    konciKolo = true;
                                }
                            } else {
                                // mimo sachovnice by som siel
                                konciKolo = true;
                            }

                            staraPoziciaFigurky = poziciaFigurky;
                            poziciaFigurky = tahy.get(volba);
                        } else {
                            staraPoziciaFigurky = poziciaFigurky;
                            konciKolo = true;
                        }

                        hraciePole.presunPanacika(staraPoziciaFigurky, tahy.get(volba));

                    } else {
                        // ak figurka uz nema dalsie mozne tahy, konci kolo hraca
                        // ak uz nema tahy a preskakovalo sa, kolo konci
                        if (preskakovaloSa) {
                            preskakovaloSa = false;
                            konciKolo = true;
                        } else {
                            System.out.println(Farba.CERVENA + "S danou figurkou sa neda hybat!" + KonzolaUtility.ANSI_RESET);
                            bolVykonanyTah = false;
                            break;
                        }
                    }

                    // kontrola, ci sme sa nedostali na protivnikov kraj sachovnice, v takom pripade sa pesiak meni na damu
                    int[] vrchnyRad = new int[2];

                    for (int i = 0; i < 8; i++) {
                        vrchnyRad[1] = i;

                        if (hraciePole.getPolicko(vrchnyRad).jePanacikNaPolicku()) {
                            Panacik panacik = hraciePole.getPolicko(vrchnyRad).getPanacik();

                            if (panacik.getFarba() == farbaHraca && panacik.getTypPanacika() == TypPanacika.PESIAK) {
                                panacik.zmenTypPanacika();
                            }
                        }
                    }

                } else {
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ MODRY ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    poziciaVedla1[0] = poziciaFigurky[0] + 1;
                    poziciaVedla1[1] = poziciaFigurky[1] + 1;


                    poziciaVedla2[0] = poziciaFigurky[0] + 1;
                    poziciaVedla2[1] = poziciaFigurky[1] - 1;

                    int mozneTahy = 0; // mozne tahy: aspoň 0

                    // hladanie tahov (lava strana - BACHA je to zrkadlovo otocene, cize uzivatel to uvidi naopak)
                    if (poziciaVedla1[0] >= 0 && poziciaVedla1[0] <= 7 && poziciaVedla1[1] >= 0 && poziciaVedla1[1] <= 7) {
                        if (hraciePole.getPolicko(poziciaVedla1).jePanacikNaPolicku()) {
                            if (hraciePole.getPolicko(poziciaVedla1).getPanacik().getFarba() != farbaHraca) {
                                if (poziciaVedla1[0] + 1 >= 0 && poziciaVedla1[0] + 1 <= 7 && poziciaVedla1[1] + 1 >= 0 && poziciaVedla1[1] + 1 <= 7) {
                                    poziciaVedla11[0] = poziciaVedla1[0] + 1;
                                    poziciaVedla11[1] = poziciaVedla1[1] + 1;

                                    if (!hraciePole.getPolicko(poziciaVedla11).jePanacikNaPolicku()) {
                                        tahy.add(poziciaVedla11);
                                        posuny.add(2);
                                    }
                                }
                            }
                        } else {
                            tahy.add(poziciaVedla1);
                            posuny.add(1);
                        }
                    }

                    // hladanie tahov (prava strana - BACHA je to zrkadlovo otocene, cize uzivatel to uvidi naopak)
                    if (poziciaVedla2[0] >= 0 && poziciaVedla2[0] <= 7 && poziciaVedla2[1] >= 0 && poziciaVedla2[1] <= 7) {
                        if (hraciePole.getPolicko(poziciaVedla2).jePanacikNaPolicku()) {
                            if (hraciePole.getPolicko(poziciaVedla2).getPanacik().getFarba() != farbaHraca) {
                                if (poziciaVedla2[0] + 1 >= 0 && poziciaVedla2[0] + 1 <= 7 && poziciaVedla2[1] - 1 >= 0 && poziciaVedla2[1] - 1 <= 7) {
                                    poziciaVedla21[0] = poziciaVedla2[0] + 1;
                                    poziciaVedla21[1] = poziciaVedla2[1] - 1;

                                    if (!hraciePole.getPolicko(poziciaVedla21).jePanacikNaPolicku()) {
                                        tahy.add(poziciaVedla21);
                                        posuny.add(2);
                                    }
                                }
                            }
                        } else {
                            tahy.add(poziciaVedla2);
                            posuny.add(1);
                        }
                    }

                    System.out.println("Pocet moznych tahov: " + mozneTahy);

                    if (tahy.size() > 0) {
                        // vyber figurky
                        boolean koniecVyberuTahu = false;
                        int volba = -1;
                        int[] staraPoziciaFigurky = new int[2];

                        // vyber tahu
                        do {
                            System.out.println(hraciePole.toString());
                            String userInput = "";
                            System.out.println("Vyberte tah, ktory chcete vykonat: ");

                            for (int i = 0; i < tahy.size(); i++) {
                                System.out.println((i + 1) + ". - Tah " + "[" + (8 - poziciaFigurky[0]) + ", " + (char)(poziciaFigurky[1] + 'A') + "] -"
                                        + posuny.get(i) + "->"
                                        + " [" + (8 - tahy.get(i)[0]) + ", " + (char)(tahy.get(i)[1] + 'A') + "]");
                            }

                            userInput = scanner.next();

                            if (!Character.isDigit(userInput.charAt(0))) {
                                System.out.println("Prosim zadajte cislo...");
                                continue;
                            }

                            int temp = (userInput.charAt(0) - '0') - 1;

                            if (temp < 0 || temp >= tahy.size()) {
                                System.out.println("Prosim vyberte volbu zo zoznamu...");
                                continue;
                            }

                            volba = temp;
                            koniecVyberuTahu = true;
                        } while (!koniecVyberuTahu);

                        // vyradenie protivnikovej figurky
                        if (posuny.get(volba) == 2) {
                            preskakovaloSa = true;

                            int[] odoberanyPanacik = new int[2];

                            // ktorym smerom sme isli, ak sme sli doprava, vieme to zistit tak, ze spocitame dohromady suradnice,
                            // ak su rovnake ako povodna pozicia, tak sme sli doprava, inak dolava...
                            if ((poziciaFigurky[0] + poziciaFigurky[1]) == (tahy.get(volba)[0] + tahy.get(volba)[1])) {
                                odoberanyPanacik[0] = poziciaFigurky[0] + 1;
                                odoberanyPanacik[1] = poziciaFigurky[1] - 1;
                            } else {
                                odoberanyPanacik[0] = poziciaFigurky[0] + 1;
                                odoberanyPanacik[1] = poziciaFigurky[1] + 1;
                            }

                            hraciePole.odoberPanacika(odoberanyPanacik);

                            int[] poziciaZaVyradenym1 = new int[2];
                            poziciaZaVyradenym1[0] = tahy.get(volba)[0] + 1;
                            poziciaZaVyradenym1[1] = tahy.get(volba)[1] + 1;
                            int[] poziciaZaVyradenym2 = new int[2];
                            poziciaZaVyradenym2[0] = tahy.get(volba)[0] + 1;
                            poziciaZaVyradenym2[1] = tahy.get(volba)[1] - 1;

                            // kontrola ci sa da este skakat s panacikom (lava strana)
                            if (poziciaZaVyradenym1[0] >= 0 && poziciaZaVyradenym1[0] <= 7 && poziciaZaVyradenym1[1] >= 0 && poziciaZaVyradenym1[1] <= 7) {
                                if (hraciePole.getPolicko(poziciaZaVyradenym1).jePanacikNaPolicku()) {
                                    if (hraciePole.getPolicko(poziciaZaVyradenym1).getPanacik().getFarba() != farbaHraca) {
                                        if (poziciaZaVyradenym1[0] + 1 >= 0 && poziciaZaVyradenym1[0] + 1 <= 7 && poziciaZaVyradenym1[1] + 1 >= 0 && poziciaZaVyradenym1[1] + 1 <= 7) {
                                            if (!hraciePole.getPolicko(poziciaVedla11).jePanacikNaPolicku()) {
                                                // da sa preskocit
                                                konciKolo = false;
                                            } else {
                                                // niekto tam stoji za nim, neda sa preskocit
                                                konciKolo = true;
                                            }
                                        } else {
                                            // mimo sachovnice by som skakal, lebo je na kraji
                                            konciKolo = true;
                                        }
                                    } else {
                                        // moj panacik nejde preskocit
                                        konciKolo = true;
                                    }
                                } else {
                                    // prazdne policko, nemozem nikoho preskocit
                                    konciKolo = true;
                                }
                            } else {
                                // mimo sachovnice by som siel
                                konciKolo = true;
                            }

                            // kontrola ci sa da este skakat s panacikom (prava strana)
                            if (poziciaZaVyradenym2[0] >= 0 && poziciaZaVyradenym2[0] <= 7 && poziciaZaVyradenym2[1] >= 0 && poziciaZaVyradenym2[1] <= 7) {
                                if (hraciePole.getPolicko(poziciaZaVyradenym2).jePanacikNaPolicku()) {
                                    if (hraciePole.getPolicko(poziciaZaVyradenym2).getPanacik().getFarba() != farbaHraca) {
                                        if (poziciaZaVyradenym2[0] + 1 >= 0 && poziciaZaVyradenym2[0] + 1 <= 7 && poziciaZaVyradenym2[1] - 1 >= 0 && poziciaZaVyradenym2[1] - 1 <= 7) {
                                            if (!hraciePole.getPolicko(poziciaVedla21).jePanacikNaPolicku()) {
                                                // da sa preskocit
                                                konciKolo = false;
                                            } else {
                                                // niekto tam stoji za nim, neda sa preskocit
                                                konciKolo = true;
                                            }
                                        } else {
                                            // mimo sachovnice by som skakal, lebo je na kraji
                                            konciKolo = true;
                                        }
                                    } else {
                                        // moj panacik nejde preskocit
                                        konciKolo = true;
                                    }
                                } else {
                                    // prazdne policko, nemozem nikoho preskocit
                                    konciKolo = true;
                                }
                            } else {
                                // mimo sachovnice by som siel
                                konciKolo = true;
                            }

                            staraPoziciaFigurky = poziciaFigurky;
                            poziciaFigurky = tahy.get(volba);
                        } else {
                            staraPoziciaFigurky = poziciaFigurky;
                            konciKolo = true;
                        }

                        hraciePole.presunPanacika(staraPoziciaFigurky, tahy.get(volba));

                    } else {
                        // figurka uz nema dalsie mozne tahy, konci kolo hraca
                        // ak uz nema tahy a preskakovalo sa, kolo konci
                        if (preskakovaloSa) {
                            preskakovaloSa = false;
                        } else {
                            System.out.println(Farba.CERVENA + "S danou figurkou sa neda hybat!" + KonzolaUtility.ANSI_RESET);
                            bolVykonanyTah = false;
                            break;
                        }
                    }



                    int[] spodnyRad = new int[2];
                    spodnyRad[0] = 7;

                    for (int i = 0; i < 8; i++) {
                        spodnyRad[1] = i;

                        if (hraciePole.getPolicko(spodnyRad).jePanacikNaPolicku()) {
                            Panacik panacik = hraciePole.getPolicko(spodnyRad).getPanacik();

                            if (panacik.getFarba() == farbaHraca && panacik.getTypPanacika() == TypPanacika.PESIAK) {
                                panacik.zmenTypPanacika();
                            }
                        }
                    }

                }
            } else {
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ LOGIKA DAMY ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                int mozneTahy = 0;
                ArrayList<int[]> mozneTahyDamou = new ArrayList<>();

                // kontrola ci sa s damou vobec da hybat
                for (int smer = 0; smer < 4; smer++) {
                    int[] poziciaHladnie = new int[2];
                    poziciaHladnie[0] = poziciaFigurky[0];
                    poziciaHladnie[1] = poziciaFigurky[1];

                    // prezeranie smerov, ci sa tam nachadza nejaky tah, v pripade ak sa tam nachadza tah,
                    // ulozi si ho do arraylistu mozneTahyDamy ako mozny tah damy...
                    switch (smer) {
                        case 0:
                            // nalavo hore
                            poziciaHladnie[0]--;
                            poziciaHladnie[1]--;

                            while (poziciaHladnie[0] >= 0 && poziciaHladnie[0] <= 7 && poziciaHladnie[1] >= 0 && poziciaHladnie[1] <= 7) {
                                if (hraciePole.getPolicko(poziciaHladnie).jePanacikNaPolicku()) {
                                    if (hraciePole.getPolicko(poziciaHladnie).getPanacik().getFarba() == farbaHraca) {
                                        break;
                                    }
                                } else {
                                    // toto tu trebalo kvoli referenciam na pole spravit takto
                                    int[] poziciaNajdena = new int[2];
                                    poziciaNajdena[0] = poziciaHladnie[0];
                                    poziciaNajdena[1] = poziciaHladnie[1];
                                    mozneTahyDamou.add(poziciaNajdena);
                                    mozneTahy++;
                                }

                                poziciaHladnie[0]--;
                                poziciaHladnie[1]--;
                            }

                            break;
                        case 1:
                            // napravo hore
                            poziciaHladnie[0]--;
                            poziciaHladnie[1]++;

                            while (poziciaHladnie[0] >= 0 && poziciaHladnie[0] <= 7 && poziciaHladnie[1] >= 0 && poziciaHladnie[1] <= 7) {
                                if (hraciePole.getPolicko(poziciaHladnie).jePanacikNaPolicku()) {
                                    if (hraciePole.getPolicko(poziciaHladnie).getPanacik().getFarba() == farbaHraca) {
                                        break;
                                    }
                                } else {
                                    int[] poziciaNajdena = new int[2];
                                    poziciaNajdena[0] = poziciaHladnie[0];
                                    poziciaNajdena[1] = poziciaHladnie[1];
                                    mozneTahyDamou.add(poziciaNajdena);
                                    mozneTahy++;
                                }

                                poziciaHladnie[0]--;
                                poziciaHladnie[1]++;
                            }

                            break;
                        case 2:
                            // napravo dole
                            poziciaHladnie[0]++;
                            poziciaHladnie[1]++;

                            while (poziciaHladnie[0] >= 0 && poziciaHladnie[0] <= 7 && poziciaHladnie[1] >= 0 && poziciaHladnie[1] <= 7) {
                                if (hraciePole.getPolicko(poziciaHladnie).jePanacikNaPolicku()) {
                                    if (hraciePole.getPolicko(poziciaHladnie).getPanacik().getFarba() == farbaHraca) {
                                        break;
                                    }
                                } else {
                                    int[] poziciaNajdena = new int[2];
                                    poziciaNajdena[0] = poziciaHladnie[0];
                                    poziciaNajdena[1] = poziciaHladnie[1];
                                    mozneTahyDamou.add(poziciaNajdena);
                                    mozneTahy++;
                                }

                                poziciaHladnie[0]++;
                                poziciaHladnie[1]++;
                            }

                            break;
                        case 3:
                            // nalavo dole
                            poziciaHladnie[0]++;
                            poziciaHladnie[1]--;

                            while (poziciaHladnie[0] >= 0 && poziciaHladnie[0] <= 7 && poziciaHladnie[1] >= 0 && poziciaHladnie[1] <= 7) {
                                if (hraciePole.getPolicko(poziciaHladnie).jePanacikNaPolicku()) {
                                    if (hraciePole.getPolicko(poziciaHladnie).getPanacik().getFarba() == farbaHraca) {
                                        break;
                                    }
                                } else {
                                    int[] poziciaNajdena = new int[2];
                                    poziciaNajdena[0] = poziciaHladnie[0];
                                    poziciaNajdena[1] = poziciaHladnie[1];
                                    mozneTahyDamou.add(poziciaNajdena);
                                    mozneTahy++;
                                }

                                poziciaHladnie[0]++;
                                poziciaHladnie[1]--;
                            }

                            break;
                    }
                }

                // ak ma dama k dispozicii tahy, vyziadaj od uzivatela input, kam chce s nou ist...
                if (mozneTahy > 0) {

                    // user input pohybu pre damu
                    boolean koniecVyberuTahu = false;
                    int[] volba = new int[2];

                    do {
                        System.out.println(hraciePole.toString());
                        String userInput = "";
                        System.out.println("Zadajte kam sa chcete pohnut s damou, vo formate riadokSTLPEC, napriklad: 3C, 1a, 8H");

                        userInput = scanner.next();

                        // osetrenie user inputu, tak aby to bolo vzdy 2 suradnice a vo formate RIADOK|STLPEC napr. 3C, 1A, ...
                        if (userInput.length() != 2
                                || !Character.isDigit(userInput.charAt(0))
                                || !Character.isAlphabetic(userInput.toLowerCase().charAt(1))
                        ) {
                            System.out.println("Nezadali ste poziciu v spravnom tvare");
                            continue;
                        }

                        // kvoli pretypovavaniu sa musi odpocitavat nulty prvok, lebo cisla nezacinaju v ascii tabulke od 0
                        // a kvoli tomu ze clovek zadava cisla od 1 do 8 sa musi odcitavat 1, aby to bolo lepsie pre stroj
                        // lebo policka su cislovane od 0 po 7
                        int poziciaRiadok = userInput.charAt(0) - '0' - 1;
                        int poziciaStlpec = userInput.toLowerCase().charAt(1) - 'a'; // to iste plati tu, len pre pismena...

                        // kontrola ci sa nachadza v range 0 - 7 (pre usera 1 - 8 a A - H)
                        if (poziciaRiadok > 7
                                || poziciaRiadok < 0
                                || poziciaStlpec > 7
                                || poziciaStlpec < 0
                        ) {
                            System.out.println("Taketo policko sa nenachadza na sachovnici...");
                            continue;
                        }


                        // prerobenie user inputu na programom vyuzitelne suradnice
                        poziciaRiadok = 7 - poziciaRiadok;

                        // kontrola, ci bolo vybrate take policko, na ktore sa realne da ist (legit tah)
                        volba[0] = poziciaRiadok;
                        volba[1] = poziciaStlpec;
                        int zhoda = 0;

                        for (int[] prvok : mozneTahyDamou) {
                            if (volba[0] == prvok[0] && volba[1] == prvok[1]) {
                                zhoda++;
                            }
                        }


                        if (zhoda == 0) {
                            System.out.println("Tento tah sa neda vykonat.");
                            continue;
                        }

                        koniecVyberuTahu = true;
                    } while (!koniecVyberuTahu);

                    System.out.println("volba: " + volba[0] + " " + volba[1]);

                    hraciePole.presunPanacika(poziciaFigurky, volba);

                    // zistenie a vyradenie figuriek, ktore boli preskocene
                    // funguje to tak, ze sa zisti najprv, ktorym smerom sme sli,
                    // a na zaklade toho sa zvysuje postupne pozicia damy,
                    // tato pozicia sa kontroluje, ci sa tam nacahadza panacik,
                    // a ak ano, tak ho vyhodi
                    // nasledne sa znovu zvysi pozicia rovnakym smerom, az kym sa nerovna
                    // finalnej pozicii, ktoru si zvolil uzivatel vyssie...

                    // zistenie smeru ktorym sme sli s damou
                    int smer = -1;

                    // zistenie ci sme sli hore/dole
                    if (poziciaFigurky[0] > volba[0]) {
                        // pohyb hore
                        // zistenie ci sme sli dolava/doprava
                        if (poziciaFigurky[1] > volba[1]) {
                            // pohyb vlavo
                            smer = 0; // vlavo hore
                        } else {
                            // pohyb vpravo
                            smer = 1; // vpravo hore
                        }
                    } else {
                        // pohyb dole
                        // zistenie ci sme sli dolava/doprava
                        if (poziciaFigurky[1] > volba[1]) {
                            // pohyb vlavo
                            smer = 3; // vlavo dole
                        } else {
                            // pohyb vpravo
                            smer = 2; // vpravo dole
                        }
                    }

                    // odoberanie panacika
                    while (poziciaFigurky[0] != volba[0] && poziciaFigurky[1] != volba[1]) {
                        if (hraciePole.getPolicko(poziciaFigurky).jePanacikNaPolicku()) {
                            if (hraciePole.getPolicko(poziciaFigurky).getPanacik().getFarba() != farbaHraca) {
                                hraciePole.getPolicko(poziciaFigurky).zoberPanacika();
                            }
                        }

                        switch  (smer) {
                            case 0:
                                // vlavo hore
                                poziciaFigurky[0]--;
                                poziciaFigurky[1]--;
                                break;
                            case 1:
                                // vpravo hore
                                poziciaFigurky[0]--;
                                poziciaFigurky[1]++;
                                break;
                            case 2:
                                // vpravo dole
                                poziciaFigurky[0]++;
                                poziciaFigurky[1]++;
                                break;
                            case 3:
                                // vlavo dole
                                poziciaFigurky[0]++;
                                poziciaFigurky[1]--;
                                break;
                        }
                    }

                    // koniec tahu damou
                    break;

                } else {
                    // figurka uz nema dalsie mozne tahy, konci kolo hraca
                    // ak uz nema tahy a preskakovalo sa, kolo konci
                    if (preskakovaloSa) {
                        preskakovaloSa = false;
                        konciKolo = true;
                    } else {
                        System.out.println(Farba.CERVENA + "S danou figurkou sa neda hybat!" + KonzolaUtility.ANSI_RESET);
                        bolVykonanyTah = false;
                        break;
                    }
                }
            }
        }

        // koniec tahu
        return bolVykonanyTah;
    }
}
