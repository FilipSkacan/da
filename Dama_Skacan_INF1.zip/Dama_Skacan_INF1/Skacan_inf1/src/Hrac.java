/**
 * Trieda Hrac predstavujuca jedneho hraca
 * sluzi ako uschovna farby, mena hraca
 */
public class Hrac {
    private Farba farba;
    private String meno;

    public Hrac(Farba farba, String meno) {
        this.meno = meno;
        this.farba = farba;
    }

    public Farba getFarba() {
        return this.farba;
    }


    public String getMeno() {
        return this.meno;
    }

    /**
     * toString hraca, sluziaci len ako formatovany vypis hraca, s peknym oznacenim vypisu farby...
     * @return formatovany string hraca
     */
    @Override
    public String toString() {
        return "Hrac{" +
                "farba=" + farba + "██████" + KonzolaUtility.ANSI_RESET +
                ", meno='" + meno + '\'' +
                '}';
    }
}

