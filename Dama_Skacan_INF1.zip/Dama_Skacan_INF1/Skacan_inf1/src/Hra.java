import java.util.Scanner;

/**
 * Trieda main, sluziaca na vypis hlavneho menu, pravidiel hry, informacii o tvorcovi
 * v pripade ze sa dohra jedna hra, vypise sa znovu menu a moze sa hrat znovu...
 * Program bezi az kym sa nezvoli koniec, alebo ina interupcia.
 */
public class Hra {
    /**
     * funkcia main, sluziaca na zoskupenie vsetkych casti programu
     * vypise hlavne menu a na zaklade volby spusti danu funkciu alebo hru
     * @param args sa nevyuziva
     */
    public static void main(String[] args) {

        System.out.println("Vitajte v hre Dama - zjednodusena verzia");

        Scanner scanner = new Scanner(System.in);
        String volba = "";
        boolean koniec = false;

        do {
            hlavneMenu();
            System.out.println("\nprosim vyberte jednu z moznosti:");
            volba = scanner.next();

            switch (volba) {
                case "0":
                    System.exit(0);
                    break;
                case "1":
                    Dama dama = new Dama();
                    continue;
                case "2":
                    pravidlaHry();
                    continue;
                case "3":
                    informacieOTvorcovi();
                    continue;
                default:
                    System.out.println("Zadali ste zlu volbu...");
                    continue;
            }

            koniec = true;
        } while (!koniec);


    }

    /**
     * funkcia vypisu hlavneho menu
     */
    private static void hlavneMenu() {
        System.out.println(
                "\n\t\t       Menu:"
                        + "\n\t\t       1 - Hrať hru"
                        + "\n\t\t       2 - Pravidlá hry"
                        + "\n\t\t       3 - Informácie o tvorcovi"
                        + "\n\t\t       0 - Skončiť program"
        );
    }

    /**
     * funkcia vypisu pravidiel hry
     */
    private static void pravidlaHry() {
        System.out.println("Dáma (zjedondušená verzia)\n" +
                "Pravidlá:\n" +
                "- Hra sa hrá na 64 políčkach šachovnice (klasická šachovnica 8x8) po osem riadkov so striedaním\n" +
                "bielych a čiernych políčok v riadku.\n" +
                "- súperi majú na začiatku po osem figúrok pešiakov stojacich\n" +
                "na protiľahlých stranách v prvých dvoch radoch na čiernych políčkach\n" +
                "- všetky figúry sa pohybujú po diagonálach, nemôžu preskakovať figúrky vlastnej farby\n" +
                "- Pešiaci sa pohybujú iba dopredu. Ak neberú súperovu figúru, pohybujú sa po jednom políčku.\n" +
                "Ak berú súperovu figúru, preskočia ju a tak ju zoberú,\n" +
                "ak môžu preskočiť aj ďalšiu súperovi figúrku, môžu preskočiť a zobrať aj tú\n" +
                "- Keď pešiak dôjde na druhú stranu šachovnice, zmení sa na dámu\n" +
                "- Dáma sa pohybuje dopredu aj dozadu o ľubovoľný počet polí\n" +
                "Vyhráva hráč, ktorý zoberie súperovi všetky figúrky. ");
    }

    /**
     * funkcia vypisu informacii o tvorcovi
     */
    private static void informacieOTvorcovi() {
        System.out.println("Filip Skačan 2020/2021, " +
                "\nštud. skupina 5ZYP031" +
                "\nhra bola vytvorená ako semestrálna práca na predmet Informatika 1");
    }
}
